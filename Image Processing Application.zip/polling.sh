#!/bin/bash
#Coded by: Abdullah Suhail
#ITMO 544: Cloud Computing Technologies
#Mini Project #2 polling (not really)


sleep 90

while true

do
php /var/www/html/asuhail_mp3/image-processing.php
sleep 10

done
